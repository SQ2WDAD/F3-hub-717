F3 HUB — نفس مصدر General Hub
================================

البيانات من:
https://general-hub-clean-ontopliveltemweop.vercel.app/_serverFn/...

الرفع: لازم Vercel (مو مجرد static) عشان /api/items يشتغل.

1) ارفع المجلد كامل على Vercel
2) بعد الرفع الموقع يطلب /api/items كل 8 ثواني
3) زر ادخل = roblox://experiences/start?placeId=104715542330896&gameInstanceId=GUID

مهم:
- JobId الحقيقي (GUID) = الدخول يشتغل
- jobId = 0 = ظهوره مخفي (نفس موقعهم)
