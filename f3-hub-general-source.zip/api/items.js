// Vercel serverless proxy → General Hub serverFn (same data + real GUIDs)
export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Cache-Control", "s-maxage=5, stale-while-revalidate=10");
  if (req.method === "OPTIONS") return res.status(204).end();

  const url =
    "https://general-hub-clean-ontopliveltemweop.vercel.app/_serverFn/d68d617011062a854ebe69b52123f8398f1c53374a2a37d8d5bf8fc47b889214";

  try {
    const r = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "x-tsr-serverFn": "true",
        Origin: "https://general-hub-clean-ontopliveltemweop.vercel.app",
        Referer: "https://general-hub-clean-ontopliveltemweop.vercel.app/",
        "User-Agent": "Mozilla/5.0",
      },
    });
    const text = await r.text();
    res.status(r.status).setHeader("Content-Type", "application/json").send(text);
  } catch (e) {
    res.status(502).json({ error: String(e.message || e) });
  }
}
